from .tabwidget import TabWidget, TabWidgetConfig, TabConfig

__all__ = ["TabWidget", "TabWidgetConfig", "TabConfig"]
